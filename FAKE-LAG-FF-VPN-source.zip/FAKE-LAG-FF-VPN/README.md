# FAKE LAG FF VPN (Android demo)

This is a simple Android Studio project with a gaming-style UI, a simulated VPN status toggle, a latency slider, and a Fake Lag demo toggle. It does **not** create a VPN tunnel, alter Free Fire traffic, or affect enemy movement/damage.

## Build an APK
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync and install any requested Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.
