package com.example.fakelagff;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    int bg = Color.rgb(8,11,18), panel = Color.rgb(20,27,40), cyan = Color.rgb(0,229,255), white = Color.WHITE;
    TextView status, lagValue, vpnStatus;
    boolean fakeLag = false, vpn = false;
    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8)); return t;
    }
    LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(12),dp(14),dp(12)); l.setBackgroundColor(panel); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(8),0,dp(8)); l.setLayoutParams(p); return l; }
    Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextColor(bg); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan)); return b; }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(18),dp(20),dp(18)); root.setBackgroundColor(bg);
        TextView title = text("FAKE LAG", 30, cyan); title.setTypeface(null, Typeface.BOLD); root.addView(title);
        TextView sub = text("FF VPN  •  NETWORK LAB", 13, white); root.addView(sub);
        TextView warning = text("BẢN MÔ PHỎNG • KHÔNG CAN THIỆP FREE FIRE", 12, Color.YELLOW); root.addView(warning);
        LinearLayout vcard = card(); vcard.addView(text("TRẠNG THÁI VPN",16,white)); vpnStatus = text("Chưa kết nối VPN",15,Color.LTGRAY); vcard.addView(vpnStatus); Button vpnBtn = button("MÔ PHỎNG KẾT NỐI VPN"); vcard.addView(vpnBtn); vpnBtn.setOnClickListener(v -> { vpn = !vpn; vpnStatus.setText(vpn ? "Chế độ demo: đã bật (không tạo đường hầm VPN)" : "Chưa kết nối VPN"); vpnBtn.setText(vpn ? "TẮT CHẾ ĐỘ DEMO" : "MÔ PHỎNG KẾT NỐI VPN"); }); root.addView(vcard);
        LinearLayout lcard = card(); lcard.addView(text("ĐỘ TRỄ MẠNG MÔ PHỎNG",16,white)); lagValue = text("150 ms",24,cyan); lcard.addView(lagValue); SeekBar seek = new SeekBar(this); seek.setMax(1000); seek.setProgress(150); lcard.addView(seek); seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){lagValue.setText(p+" ms");} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }); root.addView(lcard);
        LinearLayout fcard = card(); fcard.addView(text("FAKE LAG (MÔ PHỎNG)",16,white)); status = text("Đang tắt",18,Color.LTGRAY); fcard.addView(status); Button lagBtn = button("BẬT FAKE LAG DEMO"); fcard.addView(lagBtn); lagBtn.setOnClickListener(v -> { fakeLag = !fakeLag; status.setText(fakeLag ? "Đang bật mô phỏng độ trễ" : "Đang tắt"); status.setTextColor(fakeLag ? cyan : Color.LTGRAY); lagBtn.setText(fakeLag ? "TẮT FAKE LAG DEMO" : "BẬT FAKE LAG DEMO"); }); root.addView(fcard);
        TextView foot = text("Lưu ý: ứng dụng này chỉ mô phỏng giao diện và thanh độ trễ. VPN thật cần máy chủ và cấu hình riêng; không thể làm đối thủ đứng im hoặc thay đổi sát thương trong Free Fire.",12,Color.LTGRAY); root.addView(foot);
        setContentView(root);
    }
}
